<!DOCTYPE html>

<html>
    <head>
        <style>
            button {
                cursor: pointer;
            }
        </style>
        <title>mainy</title>
    </head>
    
    <body>
        <button id="buttonDraft">Draft</button>

        <button id="buttonDog">Dog Tracker</button>

        <button id="buttonQueue">Queue Timer</button>

        <script src="home.js"></script>
    </body>
</html>